window.addEventListener('load', function() {
  // Hide the loader
  document.querySelector('.loader').style.display = 'none';
});
